package com.capitalone;

import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;

public class Validators {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static HashMap getValidUserInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a user_name parameter
        if (!input.containsKey("user_name")) {
            throw Exception.missingUsernameParameter;
        }
        // Make sure it has a email parameter
        if (!input.containsKey("email")) {
            throw Exception.missingEmailAddressParameter;
        }

        // Make sure the username is not blank
        if (input.get("username") == "") {
            throw Exception.invalidUsernameParameter;
        }

        // Make sure the email is not blank
        if (input.get("email") == "") {
            throw Exception.invalidEmailParameter;
        }

        return input;
    }
    
    public static HashMap getValidPersonInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a name parameter
        if (!input.containsKey("customer_full_name")) {
            throw Exception.missingNameParameter;
        }

        // Make sure it has a user_name parameter
        if (!input.containsKey("customer_id")) {
            throw Exception.missingCustomerIdParameter;
        }

        // Make sure the name is not blank
        if (input.get("customer_full_name") == "") {
            throw Exception.invalidNameParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("customer_id") == "") {
            throw Exception.invalidCustomerIdParameter;
        }

        return input;
    }

    
    public static HashMap getValidAddressInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a address_id parameter
        if (!input.containsKey("mail_address_key")) {
            throw Exception.missingAddressIDParameter;
        }

        // Make sure it has a city parameter
        if (!input.containsKey("mail_address_city")) {
            throw Exception.missingCityParameter;
        }

        // Make sure it has a user_name parameter
        if (!input.containsKey("mail_address_state")) {
            throw Exception.missingStateParameter;
        }

        // Make sure it has a user_name parameter
        if (!input.containsKey("mail_address_postal_code")) {
            throw Exception.missingPostalCodeParameter;
        }

        // Make sure the name is not blank
        if (input.get("mail_address_key") == "") {
            throw Exception.invalidAddressIDParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("mail_address_city") == "") {
            throw Exception.invalidCityParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("mail_address_state") == "") {
            throw Exception.invalidStateParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("mail_address_postal_code") == "") {
            throw Exception.invalidPostalCodeParameter;
        }

        return input;
    }
    
    public static HashMap getValidPhysicalAddressInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a address_id parameter
        if (!input.containsKey("phys_address_key")) {
            throw Exception.missingAddressIDParameter;
        }

        // Make sure it has a city parameter
        if (!input.containsKey("phys_address_city")) {
            throw Exception.missingCityParameter;
        }

        // Make sure it has a user_name parameter
        if (!input.containsKey("phys_address_state")) {
            throw Exception.missingStateParameter;
        }

        // Make sure it has a user_name parameter
        if (!input.containsKey("phys_address_postal_code")) {
            throw Exception.missingPostalCodeParameter;
        }

        // Make sure the name is not blank
        if (input.get("phys_address_key") == "") {
            throw Exception.invalidAddressIDParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("phys_address_city") == "") {
            throw Exception.invalidCityParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("physs_address_state") == "") {
            throw Exception.invalidStateParameter;
        }

        // Make sure the person_id is not blank
        if (input.get("phys_address_postal_code") == "") {
            throw Exception.invalidPostalCodeParameter;
        }

        return input;
    }
    public static HashMap getValidAccountInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }

        // Make sure it has an exhibitor_id parameter
        if (!input.containsKey("account_id")) {
            throw Exception.missingaccountIdParameter;
        }

        // Make sure the exhibitor_id is not blank
        if (input.get("account_id") == "") {
            throw Exception.invalidAccountIdParameter;
        }

        return input;
    }
    
    public static HashMap getValidPhoneInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }

        // Make sure it has an exhibitor_id parameter
        if (!input.containsKey("home_phone")) {
            throw Exception.missingPhoneNumberParameter;
        }

        // Make sure the exhibitor_id is not blank
        if (input.get("home_phone") == "") {
            throw Exception.invalidPhoneNumberParameter;
        }

        return input;
    }
    public static HashMap getValidEmailBody(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a name parameter
        if (!input.containsKey("email_address")) {
            throw Exception.missingEmailAddressParameter;
        }

        return input;
    }

    public static HashMap getValidAllInput(String body) throws IOException {
        HashMap input;

        // Parse the input
        try {
            input = objectMapper.readValue(body, HashMap.class);
        } catch (Exception e) {
            throw Exception.invalidInput;
        }
        // Make sure it has a name parameter
        if (!input.containsKey("person_id")) {
            throw Exception.missingEmailIdParameter;
        }
        if (!input.containsKey("email_address")) {
            throw Exception.missingEmailAddressParameter;
        }

        return input;
    }
}
