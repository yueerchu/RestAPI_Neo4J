package com.capitalone;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.util.concurrent.AbstractScheduledService;

import org.codehaus.jackson.map.ObjectMapper;
import org.joda.time.DateTime;
import org.neo4j.graphdb.*;
import org.neo4j.graphdb.index.UniqueFactory;

import java.lang.Exception;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;



public class BatchWriterService extends AbstractScheduledService {

    private static final Logger logger = Logger.getLogger(BatchWriterService.class.getName());
    private GraphDatabaseService db;
    public LinkedBlockingQueue<HashMap<String, Object>> queue = new LinkedBlockingQueue<>();
    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static final Cache<String, Long> personCache = CacheBuilder.newBuilder().maximumSize(1_000_000).build();
    public static final Cache<String, Long> emailCache = CacheBuilder.newBuilder().maximumSize(1_000_000).build();
    public static final Cache<String, Long> householdCache = CacheBuilder.newBuilder().maximumSize(1_000_000).build();
    public static final Cache<String, Long> accountCache = CacheBuilder.newBuilder().maximumSize(1_000_000).build();
    public static final Cache<String, Long> addressCache = CacheBuilder.newBuilder().maximumSize(3_000_000).build();
    public static final Cache<String, Long> phoneCache = CacheBuilder.newBuilder().maximumSize(1_000_000).build();
    

    // Optionally set a limit to the size of the queue which will force requests to block until drained.
    // public LinkedBlockingQueue<HashMap<String, Object>> queue = new LinkedBlockingQueue<>(25_000);

    private static final String ACTION = "action";
    private static final String DATA = "data";
    
    public void SetGraphDatabase(GraphDatabaseService graphDb){
        this.db = graphDb;
    }

    public final static BatchWriterService INSTANCE = new BatchWriterService();
    private BatchWriterService() {
        if (!this.isRunning()){
            this.startAsync();
            this.awaitRunning();
        }
    }

    @Override
    protected void runOneIteration() throws Exception {
        long startTime = System.nanoTime();
        long transactionTime = System.nanoTime();

        Collection<HashMap<String, Object>> writes = new ArrayList<>();

        queue.drainTo(writes);
        if(!writes.isEmpty()) {
            int i = 0;
            Transaction tx = db.beginTx();
            try {
                HashMap input;
                int action;
                for (HashMap write : writes) {
                    try {
                        i++;
                        switch ((BatchWriterServiceAction) write.get(ACTION)) {
                        case CREATE_CUSTOMER:
                                 if (write.get(DATA) != null &&
                                    ((HashMap)write.get(DATA)).containsKey("customer_id") &&
                                    ((HashMap)write.get(DATA)).containsKey("customer_ln") ) {
                	
                            
                                String userId = (String)((HashMap)write.get(DATA)).get("customer_id");
                                String personLastName = (String)((HashMap)write.get(DATA)).get("customer_ln");
                                String personFirstName = (String)((HashMap)write.get(DATA)).get("customer_fn");
                                String personMiddleName = (String)((HashMap)write.get(DATA)).get("customer_mn");
                                String personFullName = (String)((HashMap)write.get(DATA)).get("customer_full_name");
                                String personSSN = (String)((HashMap)write.get(DATA)).get("customer_ssn");
                                String personGender = (String)((HashMap)write.get(DATA)).get("customer_gender");
                                String personMarital = (String)((HashMap)write.get(DATA)).get("customer_marital");
                                Long userNodeId = BatchWriterService.personCache.getIfPresent(userId);
                            		if(userNodeId == null){

                            			Node personNode = db.createNode(Labels.Customer);
                            			personNode.setProperty("customer_id", userId);
                            			personNode.setProperty("last_name", personLastName);
                            			personNode.setProperty("first_name", personFirstName);
                            			personNode.setProperty("middle_name", personMiddleName);
                            			personNode.setProperty("full_name", personFullName);
                            			personNode.setProperty("gender", personGender);
                            			personNode.setProperty("ssn", personSSN);
                            			personNode.setProperty("marital_status", personMarital);
                                                        			
                            			BatchWriterService.personCache.put((String) userId, personNode.getId());
                            		}
                            }
                            break;
                        case CREATE_EMAIL:
                            if (write.get(DATA) != null &&
                               ((HashMap)write.get(DATA)).containsKey("email_address") ) {
                       
                            	String email_address = (String)((HashMap)write.get(DATA)).get("email_address");
                            	Long emailNodeID = BatchWriterService.emailCache.getIfPresent(email_address);
                            	if(emailNodeID == null){

                            		Node emailNode = db.createNode(Labels.Email);
                            		emailNode.setProperty("email_address", email_address);
                            		BatchWriterService.emailCache.put((String) email_address, emailNode.getId());
                            	}
                            }
                            break;
                        case CREATE_ACCOUNT:
                            if (write.get(DATA) != null &&
                               ((HashMap)write.get(DATA)).containsKey("account_id") ) {
                       
                            	String strAccountID = (String)((HashMap)write.get(DATA)).get("account_id");
                            	String strAccountStatus = (String)((HashMap)write.get(DATA)).get("account_status");
                            	String strAccountOpenDate = (String)((HashMap)write.get(DATA)).get("account_open_date");
                            	Long accountNodeID = BatchWriterService.accountCache.getIfPresent(strAccountID);
                            	if(accountNodeID == null){
                            		Node accountNode = db.createNode(Labels.Account);
                            		accountNode.setProperty("account_id", strAccountID);
                            		accountNode.setProperty("account_status", strAccountStatus);
                            		accountNode.setProperty("account_open_date", strAccountOpenDate);
                            		BatchWriterService.accountCache.put((String) strAccountID, accountNode.getId());
                            	}
                            }
                            break;
                        case CREATE_PHONE:
                            if (write.get(DATA) != null &&
                               ((HashMap)write.get(DATA)).containsKey("phone_number") ) {
                       
                            	String strPhoneID = (String)((HashMap)write.get(DATA)).get("phone_number");
                            	String strPhoneType = (String)((HashMap)write.get(DATA)).get("phone_type");
                            	Long phoneNodeID = BatchWriterService.phoneCache.getIfPresent(strPhoneID);
                            	if(phoneNodeID == null){
                            		Node phoneNode = db.createNode(Labels.PhoneNumber);
                            		phoneNode.setProperty("phone_number", strPhoneID);
                            		phoneNode.setProperty("phone_type", strPhoneType);
                            		BatchWriterService.phoneCache.put((String) strPhoneID, phoneNode.getId());
                            	}
                            }
                            break;
                        case CREATE_ADDRESS:
                            if (write.get(DATA) != null &&
                               ((HashMap)write.get(DATA)).containsKey("mail_address_key") ) {
                       
                            	String strAddressID = (String)((HashMap)write.get(DATA)).get("mail_address_key");
                            	Long addressNodeID = BatchWriterService.addressCache.getIfPresent(strAddressID);
                            	if(addressNodeID == null){
                            		Node addressNode = db.createNode(Labels.Address);
                            		addressNode.setProperty("address_key", strAddressID);
                            		addressNode.setProperty("address_1",  (String)((HashMap)write.get(DATA)).get("mail_address_1"));
                            		addressNode.setProperty("address_2",  (String)((HashMap)write.get(DATA)).get("mail_address_2"));
                            		addressNode.setProperty("city",  (String)((HashMap)write.get(DATA)).get("mail_city"));
                            		addressNode.setProperty("state",  (String)((HashMap)write.get(DATA)).get("mail_state"));
                            		addressNode.setProperty("postalcode",  (String)((HashMap)write.get(DATA)).get("mail_postalcode"));
                            		addressNode.setProperty("country",  (String)((HashMap)write.get(DATA)).get("mail_country"));
                            		addressNode.setProperty("description",  (String)((HashMap)write.get(DATA)).get("mail_description"));
                            		BatchWriterService.addressCache.put((String) strAddressID, addressNode.getId());
                            	}
                            }
                            break;
                        case CREATE_PHYSICAL_ADDRESS:
                            if (write.get(DATA) != null &&
                            ((HashMap)write.get(DATA)).containsKey("phys_address_key") ) {
                    
                         	String strAddressID = (String)((HashMap)write.get(DATA)).get("phys_address_key");
                         	Long addressNodeID = BatchWriterService.addressCache.getIfPresent(strAddressID);
                         	if(addressNodeID == null){
                         		Node addressNode = db.createNode(Labels.PhysicalAddress);
                         		addressNode.setProperty("address_key", strAddressID);
                         		addressNode.setProperty("address_1",  (String)((HashMap)write.get(DATA)).get("phys_address_1"));
                         		addressNode.setProperty("address_2",  (String)((HashMap)write.get(DATA)).get("phys_address_2"));
                         		addressNode.setProperty("city",  (String)((HashMap)write.get(DATA)).get("phys_city"));
                         		addressNode.setProperty("state",  (String)((HashMap)write.get(DATA)).get("phys_state"));
                         		addressNode.setProperty("postalcode",  (String)((HashMap)write.get(DATA)).get("phys_postalcode"));
                         		addressNode.setProperty("country",  (String)((HashMap)write.get(DATA)).get("phys_country"));
                         		addressNode.setProperty("description",  (String)((HashMap)write.get(DATA)).get("phys_description"));
                         		BatchWriterService.addressCache.put((String) strAddressID, addressNode.getId());
                         	}
                         }
                         break;

                        case CREATE_ALL:
                            if (write.get(DATA) != null &&
                               ((HashMap)write.get(DATA)).containsKey("person_id") ) {
                            	boolean exists=false;
                            	// Person
                                String userId = (String)((HashMap)write.get(DATA)).get("customer_id");
                                String personLastName = (String)((HashMap)write.get(DATA)).get("customer_ln");
                                String personFirstName = (String)((HashMap)write.get(DATA)).get("customer_fn");
                                String personMiddleName = (String)((HashMap)write.get(DATA)).get("customer_mn");
                                String personFullName = (String)((HashMap)write.get(DATA)).get("customer_full_name");
                                String personSSN = (String)((HashMap)write.get(DATA)).get("customer_ssn");
                                String personGender = (String)((HashMap)write.get(DATA)).get("customer_gender");
                                String personMarital = (String)((HashMap)write.get(DATA)).get("customer_marital");
                            	Long userNodeId = BatchWriterService.personCache.getIfPresent(userId);
                            	if(userNodeId == null){
                                   	Node userNode = db.findNode(Labels.Customer, "person_id", (String)((HashMap)write.get(DATA)).get("person_id"));
                            		if (userNode == null) {
                               			Node personNode = db.createNode(Labels.Customer);
                            			personNode.setProperty("customer_id", userId);
                            			personNode.setProperty("sor_id", (String)((HashMap)write.get(DATA)).get("sor_id"));
                            			personNode.setProperty("person_id", (String)((HashMap)write.get(DATA)).get("person_id"));
                            			personNode.setProperty("last_name", personLastName);
                            			personNode.setProperty("first_name", personFirstName);
                            			personNode.setProperty("middle_name", personMiddleName);
                            			personNode.setProperty("full_name", personFullName);
                            			personNode.setProperty("gender", personGender);
                            			personNode.setProperty("ssn", personSSN);
                            			personNode.setProperty("marital_status", personMarital);
                           			BatchWriterService.personCache.put((String) userId, personNode.getId());
                                    }
                                 } else {
                                    exists = true;
                                }
                            	
                            	// Email
                            	String strEmailAddress = (String)((HashMap)write.get(DATA)).get("email_address");
                            	Long emailNodeID = BatchWriterService.emailCache.getIfPresent(strEmailAddress);
                            	if(emailNodeID == null){
                                   	Node emailNode = db.findNode(Labels.Email, "email_address", strEmailAddress);
                            		if (emailNode == null) {
                                 		emailNode = db.createNode(Labels.Email);
                                		emailNode.setProperty("email_address", strEmailAddress);
                                		BatchWriterService.emailCache.put((String) strEmailAddress, emailNode.getId());
                                       		}
                                 } else {
                                    exists = true;
                                }
                            	
                            	// Household
                            	String strHousehold = (String)((HashMap)write.get(DATA)).get("house_hold");
                            	Long houseNodeID = BatchWriterService.householdCache.getIfPresent(strHousehold);
                            	if(houseNodeID == null){
                                   	Node houseNode = db.findNode(Labels.HouseHold, "house_hold", strHousehold);
                            		if (houseNode == null) {
                            			houseNode = db.createNode(Labels.HouseHold);
                            			houseNode.setProperty("hh_cust_grp_mbrp_id", strHousehold);
                                		BatchWriterService.householdCache.put((String) strHousehold, houseNode.getId());
                                       		}
                                 } else {
                                    exists = true;
                                }

                            	// phone number
                            	String strPhoneNumber = (String)((HashMap)write.get(DATA)).get("work_phone");
                            	if (strPhoneNumber != null ) {
                            		Long phoneNodeID = BatchWriterService.phoneCache.getIfPresent(strPhoneNumber);
                            			if(phoneNodeID == null){
                            				Node workphoneNode = db.findNode(Labels.PhoneNumber, "phone_number", strPhoneNumber);
                            				if (workphoneNode == null) {
                            					workphoneNode = db.createNode(Labels.PhoneNumber);
                            					workphoneNode.setProperty("phone_number", strPhoneNumber);
                            					workphoneNode.setProperty("phone_type", "Work Phone");
                                        		BatchWriterService.phoneCache.put((String) strPhoneNumber, workphoneNode.getId());
                                        		Node userNode = db.getNodeById(personCache.getIfPresent(userId));
                                        		userNode.createRelationshipTo(workphoneNode, RelationshipTypes.USER_OF);
             
                            				}
                            			} else {
                            				exists = true;
                            			}
                            	}
                            	
                            	// Home
                            	String strHomePhoneNumber = (String)((HashMap)write.get(DATA)).get("home_phone");
                            	if (strHomePhoneNumber != null ) {
                            		Long phoneNodeID = BatchWriterService.phoneCache.getIfPresent(strHomePhoneNumber);
                            			if(phoneNodeID == null){
                            				Node homephoneNode = db.findNode(Labels.PhoneNumber, "phone_number", strHomePhoneNumber);
                            				if (homephoneNode == null) {
                            					homephoneNode = db.createNode(Labels.PhoneNumber);
                            					homephoneNode.setProperty("phone_number", strHomePhoneNumber);
                            					homephoneNode.setProperty("phone_type", "Home Phone");
                                        		BatchWriterService.phoneCache.put((String) strHomePhoneNumber, homephoneNode.getId());
                                        		Node userNode = db.getNodeById(personCache.getIfPresent(userId));
                                        		userNode.createRelationshipTo(homephoneNode, RelationshipTypes.USER_OF);
                            				}
                            			} else {
                            				exists = true;
                            			}
                            	}

                            	
                            	// Mobile
                            	String strMobilePhoneNumber = (String)((HashMap)write.get(DATA)).get("mobile_phone");
                            	if (strMobilePhoneNumber != null ) {
                            		Long mobilePhoneNodeID = BatchWriterService.phoneCache.getIfPresent(strMobilePhoneNumber);
                            			if(mobilePhoneNodeID == null){
                            				Node mobilephoneNode = db.findNode(Labels.PhoneNumber, "phone_number", strMobilePhoneNumber);
                            				if (mobilephoneNode == null) {
                            					mobilephoneNode = db.createNode(Labels.PhoneNumber);
                            					mobilephoneNode.setProperty("phone_number", strMobilePhoneNumber);
                            					mobilephoneNode.setProperty("phone_type", "Mobile Phone");
                                        		BatchWriterService.phoneCache.put((String) strMobilePhoneNumber, mobilephoneNode.getId());
                                        		Node userNode = db.getNodeById(personCache.getIfPresent(userId));
                                        		userNode.createRelationshipTo(mobilephoneNode, RelationshipTypes.USER_OF);
                            				}
                            			} else {
                            				exists = true;
                            			}
                            	}

                            	// Mailing Address
                            	
                            	String strAddressID = (String)((HashMap)write.get(DATA)).get("mail_address_key");
                            	Long addressNodeID = BatchWriterService.addressCache.getIfPresent(strAddressID);
                            	if(addressNodeID == null){
                            		Node addressNode = db.findNode(Labels.Address, "address_key", strAddressID);
                            		if (addressNode == null){
                            			addressNode = db.createNode(Labels.Address);
                                		addressNode.setProperty("address_key", strAddressID);
                                		addressNode.setProperty("address_1",  (String)((HashMap)write.get(DATA)).get("mail_address_1"));
                                		addressNode.setProperty("address_2",  (String)((HashMap)write.get(DATA)).get("mail_address_2"));
                                		addressNode.setProperty("city",  (String)((HashMap)write.get(DATA)).get("mail_city"));
                                		addressNode.setProperty("state",  (String)((HashMap)write.get(DATA)).get("mail_state"));
                                		addressNode.setProperty("postalcode",  (String)((HashMap)write.get(DATA)).get("mail_postalcode"));
                                		addressNode.setProperty("country",  (String)((HashMap)write.get(DATA)).get("mail_country"));
                                		addressNode.setProperty("description",  (String)((HashMap)write.get(DATA)).get("mail_description"));
                            			BatchWriterService.addressCache.put((String) strAddressID, addressNode.getId());
                            		}
                            	} else {
                                    exists = true;
                                }
                            	
                            	// Address
                            	
                            	String strPhysAddressID = (String)((HashMap)write.get(DATA)).get("phys_address_key");
                            	Long physAddressNodeID = BatchWriterService.addressCache.getIfPresent(strPhysAddressID);
                            	if(strPhysAddressID == null){
                            		Node physAddressNode = db.findNode(Labels.Address, "address_id", strPhysAddressID);
                            		if (physAddressNode == null){
                            			physAddressNode = db.createNode(Labels.Address);
                            			physAddressNode.setProperty("address_key", strPhysAddressID);
                            			physAddressNode.setProperty("address_1",  (String)((HashMap)write.get(DATA)).get("phys_address_1"));
                            			physAddressNode.setProperty("address_2",  (String)((HashMap)write.get(DATA)).get("phys_address_2"));
                            			physAddressNode.setProperty("city",  (String)((HashMap)write.get(DATA)).get("phys_city"));
                            			physAddressNode.setProperty("state",  (String)((HashMap)write.get(DATA)).get("phys_state"));
                            			physAddressNode.setProperty("postalcode",  (String)((HashMap)write.get(DATA)).get("phys_postalcode"));
                                 		physAddressNode.setProperty("country",  (String)((HashMap)write.get(DATA)).get("phys_country"));
                                 		physAddressNode.setProperty("description",  (String)((HashMap)write.get(DATA)).get("phys_description"));
                            			BatchWriterService.addressCache.put((String) strPhysAddressID, physAddressNode.getId());
                            		}
                            	} else {
                                    exists = true;
                                }
                            	
                            	// Account
                            	String strAccountID = (String)((HashMap)write.get(DATA)).get("account_id");   	
                            	Long accountNodeID = BatchWriterService.accountCache.getIfPresent(strAccountID);
                            	if(accountNodeID == null){
                                   	Node accountNode = db.findNode(Labels.Account, "account_id", strAccountID);
                            		if (accountNode == null) {
                                		accountNode = db.createNode(Labels.Account);
                                		
                                   		accountNode.setProperty("account_id", strAccountID);
                                		accountNode.setProperty("account_status", (String)((HashMap)write.get(DATA)).get("account_status"));
                                		accountNode.setProperty("sor_id", (String)((HashMap)write.get(DATA)).get("sor_id"));
                                		accountNode.setProperty("account_open_date", (String)((HashMap)write.get(DATA)).get("account_open_date"));
                                		accountNode.setProperty("sor_acct_stat_cd", (String)((HashMap)write.get(DATA)).get("sor_acct_stat_cd"));
                                		accountNode.setProperty("sor_acct_stat_desc", (String)((HashMap)write.get(DATA)).get("sor_acct_stat_desc"));
                                        BatchWriterService.accountCache.put((String) strAccountID, accountNode.getId());
                            		}
                                 } else {
                                    exists = true;
                                }
                            	
                            	// Relationships
                                Node userNode = db.getNodeById(personCache.getIfPresent(userId));
                                if (strAccountID != null){
                                	Node accountNode = db.getNodeById(accountCache.getIfPresent(strAccountID));
                                  	userNode.createRelationshipTo(accountNode, RelationshipTypes.OWNER_OF);
                                }
                                if (strEmailAddress != null){
                                    Node emailNode = db.getNodeById(emailCache.getIfPresent(strEmailAddress));
                                	userNode.createRelationshipTo(emailNode, RelationshipTypes.USER_OF);
                                }
                                if (strHousehold != null){
                                    Node HouseNode = db.getNodeById(householdCache.getIfPresent(strHousehold));
                                	userNode.createRelationshipTo(HouseNode, RelationshipTypes.BELONGS);
                                }
                                if (strAddressID != null){
                                    Node addressNode = db.getNodeById(addressCache.getIfPresent(strAddressID));
                                	userNode.createRelationshipTo(addressNode, RelationshipTypes.MAILING_ADDRESS_FOR);
                                }
                                if (strPhysAddressID != null){
                                    Node physaddressNode = db.getNodeById(addressCache.getIfPresent(strPhysAddressID));
                                	userNode.createRelationshipTo(physaddressNode, RelationshipTypes.PHYSICAL_ADDRESS_FOR);
                                }

                               
                                }
                            break;
                    }
                } catch (Exception exception) {
                    logger.severe("Error Creating Data: " + write);
                }

                    if (i % 1_000 == 0) {
                        tx.success();
                        tx.close();
                        DateTime currently = new DateTime();
                        System.out.printf("Performed a transaction of 1,000 writes in %d [msec] @ %s \n", (System.nanoTime() - transactionTime) / 1000000, currently.toDateTimeISO());
                        transactionTime = System.nanoTime();
                        tx = db.beginTx();
                    }
                }

                tx.success();

            } finally {
                tx.close();
                DateTime currently = new DateTime();
                System.out.printf("Performed a set of transactions with %d writes in %d [msec] @ %s \n", writes.size(), (System.nanoTime() - startTime) / 1000000, currently.toDateTimeISO());
            }
        }
    }

    @Override
    protected Scheduler scheduler() {
            return Scheduler.newFixedRateSchedule(0, 1, TimeUnit.SECONDS);
    }
}
