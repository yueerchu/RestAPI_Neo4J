package com.capitalone;

import org.neo4j.graphdb.RelationshipType;

public enum RelationshipTypes implements RelationshipType {
    HAS,
    LIVES_AT,
    USER_OF,
    OWNER_OF,
    MAILING_ADDRESS_FOR,
    BELONGS,
    PHYSICAL_ADDRESS_FOR
}
