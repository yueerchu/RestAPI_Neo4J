package com.capitalone;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class Exception extends WebApplicationException {

    public Exception(int code, String error)  {
        super(new Throwable(error), Response.status(code)
                .entity("{\"error\":\"" + error + "\"}")
                .type(MediaType.APPLICATION_JSON)
                .build());

    }

    public static Exception invalidInput = new Exception(400, "Invalid Input");
    public static Exception missingUsernameParameter = new Exception(400, "Missing user_name Parameter.");
    public static Exception missingEmailIdParameter = new Exception(400, "Missing email_id Parameter.");
    public static Exception missingEmailAddressParameter = new Exception(400, "Missing email_address Parameter.");
    public static Exception missingNameParameter = new Exception(400, "Missing customer_full_name Parameter.");
    public static Exception missingCustomerIdParameter = new Exception(400, "Missing customer_id Parameter.");
    public static Exception missingAddressIDParameter = new Exception(400, "Missing address_id Parameter.");
    public static Exception missingCityParameter = new Exception(400, "Missing address_city Parameter.");
    public static Exception missingStateParameter = new Exception(400, "Missing address_state Parameter.");
    public static Exception missingPostalCodeParameter = new Exception(400, "Missing address_postal_code Parameter.");
    public static Exception missingaccountIdParameter = new Exception(400, "Missing account_id Parameter.");
    public static Exception missingPhoneNumberParameter = new Exception(400, "Missing phone_number Parameter.");

    public static Exception invalidUsernameParameter = new Exception(400, "Invalid user_name Parameter.");
    public static Exception invalidEmailParameter = new Exception(400, "Invalid email Parameter.");
    public static Exception invalidNameParameter = new Exception(400, "Invalid customer_full_name Parameter.");
    public static Exception invalidCustomerIdParameter = new Exception(400, "Invalid customer_id Parameter.");
    public static Exception invalidExhibitorIdParameter = new Exception(400, "Invalid exhibitor_id Parameter.");
    public static Exception invalidEntryTimestampParameter = new Exception(400, "Invalid entry_timestamp Parameter.");
    public static Exception invalidExitTimestampParameter = new Exception(400, "Invalid exit_timestamp Parameter.");
    public static Exception invalidAddressIDParameter = new Exception(400, "Invalid address_id Parameter.");
    public static Exception invalidCityParameter = new Exception(400, "Invalid address_city Parameter.");
    public static Exception invalidStateParameter = new Exception(400, "Invalid address_state Parameter.");
    public static Exception invalidPostalCodeParameter = new Exception(400, "Invalid address_postal_code Parameter.");
    public static Exception invalidAccountIdParameter = new Exception(400, "Invalid account_id Parameter.");
    public static Exception invalidPhoneNumberParameter = new Exception(400, "Invalid phone_number Parameter.");

}
