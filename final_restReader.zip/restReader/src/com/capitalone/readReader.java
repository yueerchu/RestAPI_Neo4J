package com.capitalone;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.lang3.StringEscapeUtils;

/**
 * The HelloWorldApp class implements an application that
 * simply displays "Hello World!" to the standard output.
 */
class HelloWorldApp {
	
	private static HttpURLConnection connection = null;
	private static URL url = null; 
	private static OutputStreamWriter writer = null;
	private static BufferedReader br = null;
	private static HttpClient httpclient = null;
	
	//private static HttpClient httpclient = null;
	//private static PostMethod post = null;
	
    public static void init() throws Exception {
		httpclient = new HttpClient();
		
		    //url = new URL("http://10.94.66.141:8080/v1/service/createAll");
//		    url = new URL("http://localhost:7474/v1/service/createAll");
//			connection = (HttpURLConnection) url.openConnection();
//            String basicAuth = "Basic bmVvNGo6cGV0ZXJ0dWRvdQ==";
//            connection.setRequestProperty ("Authorization", basicAuth);
//            connection.setDoInput(true);
//            connection.setDoOutput(true);
//            connection.setRequestMethod("POST");
//            connection.setRequestProperty("Accept", "application/json");
//            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
//			
//			writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
//			
//         	br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
         	//start
         	
//         	post = new PostMethod("http://localhost:7474/v1/service/createAll");
//         	
//         	post.setRequestHeader("Accept", "application/json");
//         	post.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
//         	String basicAuth2 = "Basic bmVvNGo6cGV0ZXJ0dWRvdQ==";
//         	post.setRequestHeader("Authorization", basicAuth2);
//         	
         	
//         	try {
//                
//                int result = httpclient.executeMethod(post);
//                 
//                // Display status code
//                System.out.println("Response status code: " + result);
//                 
//                // Display response
//                System.out.println("Response body: ");
//                System.out.println(post.getResponseBodyAsString());
//                 
//            } finally {
//                // Release current connection to the connection pool 
//                // once you are done
//                post.releaseConnection();
//            }
//         	
			return;
	}	
	
	public static void cleanup() throws Exception {
		    writer.close();
			br.close();
	        connection.disconnect();
	}
			
    public static void main(String[] args) {
        String line;
        StringBuffer jsonString = new StringBuffer();
		
        try { 
            URL url = new URL("http://localhost:7474/v1/service/createAll");
            // URL url = new URL("http://10.94.66.141:8080/v1/service/createAll");
            URL emailURL = new URL("http://localhost:7474/v1/service/email");
            URL addAllURL = new URL("http://localhost:7474/v1/service/createAll");
            String strEmail = null;
            String strCustomerName = null;
            String strFirstName = null;
            String strMiddleName = null;
            String strLastName = null;
            String strCustomerID = null;
            String strCustomerSSN = null;
            String strCustomerGender = null;
            String strCustomerMarital = null;
            String strWorkPhone = null;
            String strHomePhone = null;
            String strMobilePhone = null;
            String strAccountID = null;
            String strAccountStatus = null;
            String strAccountOpenDate = null;
            String strSorCustID = null;
            String strMailAddr1 = null;
            String strMailAddr2 = null;          
            String strMailCity = null;
            String strMailState = null;          
            String strMailPostalCode = null;
            String strMailCountry = null; 
            String strMailDescr = null;
            String strPhysAddr1 = null;
            String strPhysAddr2 = null;          
            String strPhysCity = null;
            String strPhysState = null;          
            String strPhysPostalCode = null;
            String strPhysCountry = null; 
            String strPhysDescr = null;
			
            int i = 0;
			
		    // init HTTP connection
		    init();
			
            BufferedReader in = new BufferedReader(new FileReader("/Users/GHL336/Downloads/full.csv"));
			
            while ((line = in.readLine()) != null) {
            	i = i + 1;
            	System.out.println(i);
            	if (i > 0) {
					String parts[] = line.split("\001");
					strAccountID = parts[2];
					strAccountStatus = StringEscapeUtils.escapeJava(parts[6]);
					//System.out.println(strAccountStatus);
					strAccountOpenDate = parts[36];
                 
					strSorCustID = parts[1];
					strCustomerName = StringEscapeUtils.escapeJava(parts[9]);
					strFirstName = StringEscapeUtils.escapeJava(parts[10]);
					strMiddleName = parts[11];
					strLastName = parts[12];
					strCustomerID = parts[44];
					strCustomerSSN = parts[31];
					strCustomerGender = parts[32];
					strCustomerMarital = parts[33];
                                 
					strMailAddr1 = StringEscapeUtils.escapeJava(parts[13]);
					strMailAddr2 =StringEscapeUtils.escapeJava(parts[14]);
					strMailCity =parts[15];
					strMailState =parts[16];
					strMailPostalCode =parts[17];
					strMailCountry =parts[18];
					strMailDescr =parts[19];

					strPhysAddr1 = StringEscapeUtils.escapeJava(parts[20]);
					strPhysAddr2 =StringEscapeUtils.escapeJava(parts[21]);
					strPhysCity =parts[22];
					strPhysState =parts[23];
					strPhysPostalCode =parts[24];
					strPhysCountry =parts[25];
					strPhysDescr =parts[26];
					strPhysDescr = strPhysDescr.replace("\\", "\\\\");
                              
					strHomePhone = parts[27];
					strWorkPhone = parts[28];
					strMobilePhone = parts[29];

					strEmail = StringEscapeUtils.escapeJava(parts[30]);
            
            

					//escape the double quotes in json string
					/**
					*
					HttpURLConnection connection = (HttpURLConnection) url.openConnection();
					String basicAuth = "Basic bmVvNGo6cGV0ZXJ0dWRvdQ==";
					connection.setRequestProperty ("Authorization", basicAuth);

					connection.setDoInput(true);
					connection.setDoOutput(true);
					connection.setRequestMethod("POST");
					connection.setRequestProperty("Accept", "application/json");
					connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
					*/
            
					String payload="{\"person_id\" : \"" + strSorCustID 
            		   + "\",\"email_address\":\"" + strEmail
              		   + "\",\"account_id\":\"" + strAccountID
              		   + "\",\"account_status\":\"" + strAccountStatus
              		   + "\",\"account_open_date\":\"" + strAccountOpenDate
              		   + "\",\"customer_id\":\"" + strCustomerID
              		   + "\",\"customer_fn\":\"" + strFirstName
              		   + "\",\"customer_mn\":\"" + strMiddleName
              		   + "\",\"customer_ln\":\"" + strLastName
              		   + "\",\"customer_full_name\":\"" + strCustomerName
              		   + "\",\"customer_ssn\":\"" + strCustomerSSN
              		   + "\",\"customer_gender\":\"" + strCustomerGender
              		   + "\",\"customer_marital\":\"" + strCustomerMarital
              		   + "\",\"mail_address_key\":\"" + strMailAddr1 + " " + strMailAddr2  + " " + strMailCity + " " +strMailState + " " + strMailPostalCode + " " + strMailCountry
              		   + "\",\"mail_address_1\":\"" +  strMailAddr1
              		   + "\",\"mail_address_2\":\"" + strMailAddr2
              		   + "\",\"mail_address_city\":\"" + strMailCity
              		   + "\",\"mail_address_state\":\"" + strMailState
              		   + "\",\"mail_address_postal_code\":\"" + strMailPostalCode
              		   + "\",\"mail_address_country\":\"" + strMailCountry
              		   + "\",\"mail_address_descr\":\"" + strMailDescr
              		   + "\",\"phys_address_key\":\"" + strPhysAddr1 + " " + strPhysAddr2 + " " + strPhysCity + " " + strPhysState + " " + strPhysPostalCode+ " " + strPhysCountry
              		   + "\",\"phys_address_1\":\"" +  strPhysAddr1
              		   + "\",\"phys_address_2\":\"" + strPhysAddr2
              		   + "\",\"phys_address_city\":\"" + strPhysCity
              		   + "\",\"phys_address_state\":\"" + strPhysState
              		   + "\",\"phys_address_postal_code\":\"" + strPhysPostalCode
              		   + "\",\"phys_address_country\":\"" + strPhysCountry
              		   + "\",\"phys_address_descr\":\"" + strPhysDescr
              		   + "\",\"home_phone\":\"" + strHomePhone
              		   + "\",\"work_phone\":\"" + strWorkPhone
              		   + "\",\"mobile_phone\":\"" + strMobilePhone
              		   
              		   + "\"}";
					//System.out.println(payload);
			   
					// OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
					//writer.write(payload);
					// writer.close();
					// BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            
					InputStream stream = new ByteArrayInputStream(payload.getBytes(StandardCharsets.UTF_8));
					PostMethod post = new PostMethod("http://10.94.66.141:8080/v1/service/createAll");
          	
					post.setRequestHeader("Accept", "application/json");
					post.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
					String basicAuth2 = "Basic bmVvNGo6cGV0ZXJ0dWRvdQ==";
					post.setRequestHeader("Authorization", basicAuth2);
					post.setRequestEntity(new InputStreamRequestEntity(stream));
					 
					try {
						// HttpClient httpclient = new HttpClient();
						int result = httpclient.executeMethod(post);
              
						// Display status code
						System.out.println("Response status code: " + result);
               
						// Display response
              
						//         	   while ((line = br.readLine()) != null) {
						////                    jsonString.append(line);
						//         	   }
						// br.close();
           
						// connection.disconnect();
					}
					catch (HttpException e) {
						System.err.println("Fatal protocol violation: " + e.getMessage());
						e.printStackTrace();
					} catch (IOException e) {
						System.err.println("Fatal transport error: " + e.getMessage());
						e.printStackTrace();
					} finally {
						// Release the connection.
						post.releaseConnection();
					} // end of try
					
					//Thread.sleep(10);
            	} // end of if (i > 0)
        	} // end of while
			
            in.close();
			
			// disconnect HTTP connection
			cleanup();

            System.out.println("completed");
            
        } catch (Exception e) {
        	e.printStackTrace();
                throw new RuntimeException(e.getMessage());
        }

     }
}