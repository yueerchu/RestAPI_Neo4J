package com.capitalone;

public enum BatchWriterServiceAction {
    CREATE_USER,
    CREATE_EMAIL,
    CREATE_ADDRESS,
    CREATE_ACCOUNT,
    CREATE_PHONE,
    CREATE_ALL, 
    CREATE_PHYSICAL_ADDRESS, 
    CREATE_CUSTOMER
}
