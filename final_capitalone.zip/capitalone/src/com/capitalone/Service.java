package com.capitalone;

import org.codehaus.jackson.map.ObjectMapper;
import org.neo4j.graphdb.*;
import org.neo4j.graphdb.schema.Schema;
import org.neo4j.tooling.GlobalGraphOperations;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

@Path("/service")
public class Service {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static final BatchWriterService batchWriterService = BatchWriterService.INSTANCE;

    public static final String ACTION = "action";
    public static final String DATA = "data";
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-M-d-H-m");

    public Service(@Context GraphDatabaseService graphdb) {
        batchWriterService.SetGraphDatabase(graphdb);
    }

    @GET
    @Path("/helloworlds")
    public String helloWorld() {
        return "Hello World!";
    }

    @GET
    @Path("/warmup")
    public String warmUp(@Context GraphDatabaseService db) {
        try ( Transaction tx = db.beginTx() )
        {
            ResourceIterator<Node> iter = db.findNodes(Labels.Customer);
            while(iter.hasNext()) {
                Node userNode = iter.next();
                userNode.getPropertyKeys();
                BatchWriterService.personCache.put((String) userNode.getProperty("person_id"), userNode.getId());
            }

            iter = db.findNodes(Labels.Address);
            while(iter.hasNext()) {
                Node addressNode = iter.next();
                addressNode.getPropertyKeys();
                BatchWriterService.addressCache.put((String) addressNode.getProperty("address_key"), addressNode.getId());
            }

            iter = db.findNodes(Labels.PhysicalAddress);
            while(iter.hasNext()) {
                Node addressNode = iter.next();
                addressNode.getPropertyKeys();
                BatchWriterService.addressCache.put((String) addressNode.getProperty("address_key"), addressNode.getId());
            }
            
            iter = db.findNodes(Labels.Email);
            while(iter.hasNext()) {
                Node emailNode = iter.next();
                emailNode.getPropertyKeys();
                BatchWriterService.emailCache.put((String) emailNode.getProperty("email_address"), emailNode.getId());
            }

            iter = db.findNodes(Labels.Account);
            while(iter.hasNext()) {
                Node accountNode = iter.next();
                accountNode.getPropertyKeys();
                BatchWriterService.accountCache.put((String) accountNode.getProperty("account_id"), accountNode.getId());
            }

            for ( Relationship relationship : GlobalGraphOperations.at(db).getAllRelationships()){
                relationship.getPropertyKeys();
                relationship.getNodes();
            }
        }
        return "Warmed up and ready to go!";
    }
    
    @GET
    @Path("/clearCache")
    public String clearCache(@Context GraphDatabaseService db) {
        try ( Transaction tx = db.beginTx() )
        {
            BatchWriterService.personCache.invalidateAll();
            BatchWriterService.addressCache.invalidateAll();
            BatchWriterService.emailCache.invalidateAll();
            BatchWriterService.accountCache.invalidateAll();            
            BatchWriterService.phoneCache.invalidateAll();   
            BatchWriterService.householdCache.invalidateAll(); 
        }
        return "Caches cleared!!!";
    }


    @GET
    @Path("/migrate")
    public String migrate(@Context GraphDatabaseService db) {
        boolean migrated;
        try (Transaction tx = db.beginTx()) {
            migrated = db.schema().getConstraints().iterator().hasNext();
        }

        if (migrated) {
            return "Already Migrated!";
        } else {
            // Perform Migration
            try (Transaction tx = db.beginTx()) {
                Schema schema = db.schema();
                schema.constraintFor(Labels.Customer)
                        .assertPropertyIsUnique("person_id")
                        .create();
                schema.constraintFor(Labels.Email)
                        .assertPropertyIsUnique("email_address")
                        .create();
                schema.constraintFor(Labels.HouseHold)
                		.assertPropertyIsUnique("house_hold")
                		.create();
                schema.constraintFor(Labels.Account)
                        .assertPropertyIsUnique("account_id")
                        .create();
                schema.constraintFor(Labels.Address)
                        .assertPropertyIsUnique("address_key")
                        .create();
                schema.constraintFor(Labels.PhysicalAddress)
                		.assertPropertyIsUnique("address_key")
                		.create();
                schema.constraintFor(Labels.PhoneNumber)
                		.assertPropertyIsUnique("phone_number")
                		.create();
                tx.success();
            }
            // Wait for indexes to come online
            try (Transaction tx = db.beginTx()) {
                Schema schema = db.schema();
                schema.awaitIndexesOnline(1, TimeUnit.DAYS);
            }
            return "Migrated!";
        }
    }

    @POST
    @Path("/customer")
    public Response createUser(String body, @Context GraphDatabaseService db) throws IOException, InterruptedException{
        HashMap input = Validators.getValidPersonInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();
        
        boolean exists = false;
        try (Transaction tx = db.beginTx()) {
        	Long userNodeId = BatchWriterService.personCache.getIfPresent(input.get("customer_id"));
        	if(userNodeId == null){
        		Node user = db.findNode(Labels.Customer, "customer_id", input.get("customer_id"));   		
        		if (user == null) {
        			data.put("customer_id", input.get("customer_id"));
        			data.put("customer_fn", input.get("customer_fn"));
        			data.put("customer_mn", input.get("customer_mn"));
        			data.put("customer_ln", input.get("customer_ln"));
        			data.put("customer_full_name", input.get("customer_full_name"));
        			data.put("customer_ssn", input.get("customer_ssn"));
        			data.put("customer_gender", input.get("customer_gender"));
        			data.put("customer_marital", input.get("customer_marital"));
        			write.put(ACTION, BatchWriterServiceAction.CREATE_CUSTOMER);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }

            tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }

    @POST
    @Path("/phone")
    public Response createPhoneNumber(String body, @Context GraphDatabaseService db) throws IOException, InterruptedException{
        HashMap input = Validators.getValidPhoneInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();
        
        boolean exists = false;
        try (Transaction tx = db.beginTx()) {
        	Long workPhoneId = BatchWriterService.phoneCache.getIfPresent(input.get("work_phone"));
        	if(workPhoneId == null){
        		Node workPhoneNode = db.findNode(Labels.PhoneNumber, "phone_number", input.get("work_phone"));   		
        		if (workPhoneNode == null) {
        			data.put("phone_number", input.get("work_phone"));
        			data.put("phone_type", "Work Phone");
        			write.put(ACTION, BatchWriterServiceAction.CREATE_PHONE);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }

             tx.success();
        }
        
        try (Transaction tx = db.beginTx()) {
        	Long homePhoneId = BatchWriterService.phoneCache.getIfPresent(input.get("home_phone"));
        	if(homePhoneId == null){
        		Node homePhoneNode = db.findNode(Labels.PhoneNumber, "phone_number", input.get("home_phone"));   		
        		if (homePhoneNode == null) {
        			data.put("phone_number", input.get("home_phone"));
        			data.put("phone_type", "Home Phone");
        			write.put(ACTION, BatchWriterServiceAction.CREATE_PHONE);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }

             tx.success();
        }        

        try (Transaction tx = db.beginTx()) {
        	Long mobilePhoneId = BatchWriterService.phoneCache.getIfPresent(input.get("mobile_phone"));
        	if(mobilePhoneId == null){
        		Node mobilePhoneNode = db.findNode(Labels.PhoneNumber, "phone_number", input.get("mobile_phone"));   		
        		if (mobilePhoneNode == null) {
        			data.put("phone_number", input.get("mobile_phone"));
        			data.put("phone_type", "Mobile Phone");
        			write.put(ACTION, BatchWriterServiceAction.CREATE_PHONE);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }

             tx.success();
        }        
        
        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }
    @POST
    @Path("/physicaladdress")
    public Response createAddress(String body, @Context GraphDatabaseService db) throws IOException, InterruptedException {
        HashMap input = Validators.getValidPhysicalAddressInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();
        
       boolean exists = false;
        try (Transaction tx = db.beginTx()) {
           	Long addressNodeID = BatchWriterService.addressCache.getIfPresent(input.get("phys_address_key"));
        	if(addressNodeID == null){
               	Node addressNode = db.findNode(Labels.PhysicalAddress, "phys_address_key", input.get("phys_address_key"));
        		if (addressNode == null) {
        			data.put("phys_address_key", input.get("phys_address_key"));
        			data.put("phys_address_1", input.get("phys_address_1"));
        			data.put("phys_address_2", input.get("phys_address_2"));
        			data.put("phys_city", input.get("phys_address_city"));
        			data.put("phys_state", input.get("phys_address_state"));
        			data.put("phys_postalcode", input.get("phys_address_postal_code"));
        			data.put("phys_country", input.get("phys_address_country"));
        			data.put("phys_description", input.get("phys_address_descr"));
        			write.put(ACTION, BatchWriterServiceAction.CREATE_PHYSICAL_ADDRESS);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }
            tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }

    @POST
    @Path("/mailaddress")
    public Response createPhysicalAddress(String body, @Context GraphDatabaseService db) throws IOException, InterruptedException {
        HashMap input = Validators.getValidAddressInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();
        
       boolean exists = false;
        try (Transaction tx = db.beginTx()) {
           	Long addressNodeID = BatchWriterService.addressCache.getIfPresent(input.get("mail_address_key"));
        	if(addressNodeID == null){
               	Node addressNode = db.findNode(Labels.Address, "mail_address_key", input.get("mail_address_key"));
        		if (addressNode == null) {
        			data.put("mail_address_key", input.get("mail_address_key"));
        			data.put("mail_address_1", input.get("mail_address_1"));
        			data.put("mail_address_2", input.get("mail_address_2"));
        			data.put("mail_city", input.get("mail_address_city"));
        			data.put("mail_state", input.get("mail_address_state"));
        			data.put("mail_postalcode", input.get("mail_address_postal_code"));
        			data.put("mail_country", input.get("mail_address_country"));
        			data.put("mail_description", input.get("mail_address_descr"));
        			write.put(ACTION, BatchWriterServiceAction.CREATE_ADDRESS);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }
            tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }
    @POST
    @Path("/email")
    public Response createEmail(String body, @Context GraphDatabaseService db)  throws IOException, InterruptedException{
        HashMap input = Validators.getValidEmailBody(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();

        boolean exists = false;
        try (Transaction tx = db.beginTx()) {
        	Long emailNodeID = BatchWriterService.emailCache.getIfPresent(input.get("email_address"));
        	if(emailNodeID == null){
               	Node emailNode = db.findNode(Labels.Email, "email_address", input.get("email_address"));
        		if (emailNode == null) {
        			data.put("email_address", input.get("email_address"));
        			write.put(ACTION, BatchWriterServiceAction.CREATE_EMAIL);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }
             tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }
    
    @POST
    @Path("/account")
    public Response createAccount(String body, @Context GraphDatabaseService db)   throws IOException, InterruptedException {
        HashMap input = Validators.getValidAccountInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();

        boolean exists = false;
        try (Transaction tx = db.beginTx()) {
        	Long accountNodeID = BatchWriterService.accountCache.getIfPresent(input.get("account_id"));
        	if(accountNodeID == null){
               	Node accountNode = db.findNode(Labels.Account, "account_id", input.get("account_id"));
        		if (accountNode == null) {
        			data.put("account_id", input.get("account_id"));
        			data.put("account_status", input.get("account_status"));
        			data.put("account_open_date", input.get("account_open_date"));
        			write.put(ACTION, BatchWriterServiceAction.CREATE_ACCOUNT);
        			write.put(DATA, data);
        			batchWriterService.queue.put(write);
        		}
             } else {
                exists = true;
            }

            tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }
    
    @POST
    @Path("/createAll")
    public Response createAll(String body, @Context GraphDatabaseService db)   throws IOException, InterruptedException {
        HashMap input = Validators.getValidAllInput(body);
        HashMap<String, Object> write = new HashMap<>();
        HashMap<String, Object> data = new HashMap<>();

        boolean exists = false;
        try (Transaction tx = db.beginTx()) {
        	data.put("sor_id", input.get("sor_id"));
			data.put("customer_id", input.get("customer_id"));
			data.put("person_id", input.get("person_id"));
			data.put("customer_fn", input.get("customer_fn"));
			data.put("customer_mn", input.get("customer_mn"));
			data.put("customer_ln", input.get("customer_ln"));
			data.put("customer_full_name", input.get("customer_full_name"));
			data.put("customer_ssn", input.get("customer_ssn"));
			data.put("customer_gender", input.get("customer_gender"));
			data.put("customer_marital", input.get("customer_marital"));

			data.put("account_id", input.get("account_id"));
			data.put("account_status", input.get("account_status"));
			data.put("account_open_date", input.get("account_open_date"));
			data.put("sor_acct_stat_cd", input.get("sor_acct_stat_cd"));
			data.put("sor_acct_stat_desc", input.get("sor_acct_stat_desc"));

			data.put("email_address", input.get("email_address"));
			data.put("house_hold", input.get("house_hold"));

			data.put("work_phone", input.get("work_phone"));
			data.put("home_phone", input.get("home_phone"));
			data.put("mobile_phone", input.get("mobile_phone"));

			data.put("mail_address_key", input.get("mail_address_key"));
			data.put("mail_address_1", input.get("mail_address_1"));
			data.put("mail_address_2", input.get("mail_address_2"));
			data.put("mail_city", input.get("mail_address_city"));
			data.put("mail_state", input.get("mail_address_state"));
			data.put("mail_postalcode", input.get("mail_address_postal_code"));
			data.put("mail_country", input.get("mail_address_country"));
			data.put("mail_description", input.get("mail_address_descr"));

			data.put("phys_address_key", input.get("phys_address_key"));
			data.put("phys_address_1", input.get("phys_address_1"));
			data.put("phys_address_2", input.get("phys_address_2"));
			data.put("phys_city", input.get("phys_address_city"));
			data.put("phys_state", input.get("phys_address_state"));
			data.put("phys_postalcode", input.get("phys_address_postal_code"));
			data.put("phys_country", input.get("phys_address_country"));
			data.put("phys_description", input.get("phys_address_descr"));

			write.put(ACTION, BatchWriterServiceAction.CREATE_ALL);
        	write.put(DATA, data);
        	batchWriterService.queue.put(write);
            tx.success();
        }

        if (exists) {
            return Response.status(Response.Status.OK).build();
        } else {
            return Response.status(Response.Status.CREATED).build();
        }
    }
    
}