package com.capitalone;

import org.neo4j.graphdb.Label;

public enum Labels implements Label {
	PhoneNumber,
	Person,
    Account,
    Email,
    Address, 
    Company,
    MailingAddress,
    PhysicalAddress,
    HomePhone,
    WorkPhone,
    CellPhone,
    Customer,
    HouseHold
}
